function matchpass() {
    var firstpass = document.getElementById("password1").value;
    var secondpass = document.getElementById("password2").value;
    if (firstpass == secondpass)
        return true;
    else {
        alert("Both passwords must be same");
        return false;

    }
}

function isEmpty() {
    var inputdata = document.getElementsById("input-box").value;
    if (inputdata == null) {
        alert("Fields cannot be Empty");
        return true;
    }
    else {
        alert("Submitted Successfully");
        return false;
    }

}






